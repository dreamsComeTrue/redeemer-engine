/*!
**	Redeemer Engine 2010 (C) Copyright by Dominik "squ@ll" Jasi�ski.
**
**	R_Input_GUISystem.cpp
**		GUI system manages all GUI controls
*/

//------------------------------------------------------------------------------------------------------------------------
#include "R_GUI_GUISystem.h"
#include "R_GUI_GUISkinManager.h"
#include "R_GUI_GUIFontManager.h"
#include "..\\Render\\R_Render_RenderDevice.h"
#include "..\\RedeemerEngine.h"

#include <ft2build.h>
#include FT_FREETYPE_H

namespace REDEEMER
{
	namespace GUI
	{
		//------------------------------------------------------------------------------------------------------------------------
		C_GUISystem::C_GUISystem () :
			C_GUIControl (0, GUICT_System, NULL, CORE::C_Rectangle<int>(CORE::C_Vector2D<int>(0, 0),
				CORE::C_Vector2D<int>(C_RedeemerEngine::GetSingleton().GetRenderManager().GetRenderDevice()->GetRenderVideoMode().ScreenResolution.X,
					   				  C_RedeemerEngine::GetSingleton().GetRenderManager().GetRenderDevice()->GetRenderVideoMode().ScreenResolution.Y))),
			m_SkinManager (NULL),
			m_FontManager (NULL),
			m_FreeTypeLibrary (NULL),
			m_GUIMaterial (NULL)
		{
			//	EMPTY
		}

		//------------------------------------------------------------------------------------------------------------------------

		C_GUISystem::~C_GUISystem ()
		{
			if (IsInitialized())
				Finalize();
		}

		//------------------------------------------------------------------------------------------------------------------------

		int C_GUISystem::Initialize ()
		{
			C_BaseClass::Initialize();

			m_SkinManager = new C_GUISkinManager ();
			m_FontManager = new C_GUIFontManager ();

			m_SkinManager->Initialize();
			m_FontManager->Initialize();

			//	Initialize FreeType library
			int error = FT_Init_FreeType ((FT_Library*)&m_FreeTypeLibrary);

			if ( error )
			{
				REDEEMER_LOG << LOG_ERROR << L"An error occurred during initialization of FreeType2 library." << LOG_ENDMESSAGE;

				return RESULT_FAIL;
			}

			return RESULT_OK;
		}

		//------------------------------------------------------------------------------------------------------------------------

		int C_GUISystem::Finalize ()
		{
			m_FontManager->Finalize();
			m_SkinManager->Finalize();

			REDEEMER_SAFE_DELETE (m_SkinManager);
			REDEEMER_SAFE_DELETE (m_FontManager);

			//	Release FreeType library
			FT_Done_FreeType ((FT_Library)m_FreeTypeLibrary);

			return C_BaseClass::Finalize();
		}																														  

		//------------------------------------------------------------------------------------------------------------------------

		void C_GUISystem::UpdateControls ()
		{
		
		}

		//------------------------------------------------------------------------------------------------------------------------

		C_GUISkinManager* C_GUISystem::GetSkinManager ()
		{
			return m_SkinManager;
		}

		//------------------------------------------------------------------------------------------------------------------------

		C_GUIFontManager* C_GUISystem::GetFontManager ()
		{
			return m_FontManager;
		}

		//------------------------------------------------------------------------------------------------------------------------

		FT_LibraryRec_* C_GUISystem::GetFreeTypeLibrary ()
		{
			return m_FreeTypeLibrary;
		}

		//------------------------------------------------------------------------------------------------------------------------

		void C_GUISystem::SetGUIMaterial (RENDER::C_Material* material)
		{
			m_GUIMaterial = material;
		}

		//------------------------------------------------------------------------------------------------------------------------

		RENDER::C_Material* C_GUISystem::GetGUIMaterial ()
		{
			return m_GUIMaterial;
		}

		//------------------------------------------------------------------------------------------------------------------------

	}	//	namespace GUI
}	//	namespace REDEEMER
