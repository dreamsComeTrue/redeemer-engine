/*!
**	Redeemer Engine 2010 (C) Copyright by Dominik "squ@ll" Jasi�ski.
**
**	R_Input_GUIStaticText.h
**		GUI Control which uses C_Sprite to render an image
*/

//------------------------------------------------------------------------------------------------------------------------
#ifndef _R_GUI_GUISTATICTEXT_H_
#define _R_GUI_GUISTATICTEXT_H_

#include "R_GUI_GUIControl.h"
	
namespace REDEEMER
{
	namespace RENDER
	{
		class C_Texture;
		class C_Sprite;
		class C_Material;
	}

	namespace GUI
	{
		/*!
		**	\brief GUI Control which uses C_Sprite to render an image
		*/
		class C_GUIStaticText : public C_GUIControl
		{
		public:
			/*!	Constructor
			*/
			C_GUIStaticText (unsigned int ID, C_GUIControl* parent, CORE::C_Rectangle<int> dimensions);

			/*!	Destructor
			*/
			virtual ~C_GUIStaticText ();


			/*!	Draws control on the screen
			*/
			virtual void Render ();

		private:
			RENDER::C_Sprite*	m_Sprite;			///<	Surface used for drawing
			RENDER::C_Texture*	m_OldTexture;
			RENDER::C_Texture*	m_Texture;
			RENDER::C_Material*	m_GUIMaterial;
		};

	}	//	namespace GUI
}	//	namespace REDEEMER

#endif	//	_R_GUI_GUISTATICTEXT_H_
