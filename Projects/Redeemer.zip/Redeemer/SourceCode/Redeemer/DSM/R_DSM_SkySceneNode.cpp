/*!
**	Redeemer Engine 2010 (C) Copyright by Dominik "squ@ll" Jasi�ski.
**
**	R_DSM_SkySceneNode.cpp
**		Abstract class to represent sky node
*/

//------------------------------------------------------------------------------------------------------------------------
#include "R_DSM_SkySceneNode.h"

namespace REDEEMER
{
	namespace DSM
	{
		//------------------------------------------------------------------------------------------------------------------------
		C_DSMSkySceneNode::C_DSMSkySceneNode ()
		{
			//	EMPTY
		}

		//------------------------------------------------------------------------------------------------------------------------

		C_DSMSkySceneNode::~C_DSMSkySceneNode ()
		{
			//	EMPTY
		}

		//------------------------------------------------------------------------------------------------------------------------

	}	//	namespace DMS
}	//	namespace REDEEMER
