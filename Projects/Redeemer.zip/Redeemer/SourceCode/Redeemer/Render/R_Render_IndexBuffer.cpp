/*!
**	Redeemer Engine 2010 (C) Copyright by Dominik "squ@ll" Jasi�ski.
**
**	R_Render_IndexBuffer.cpp
**		Generic implementation of Index Buffer - an ordered collection of vertices' indexes
*/

//------------------------------------------------------------------------------------------------------------------------
#include "R_Render_IndexBuffer.h"

namespace REDEEMER
{
	namespace RENDER
	{	
		C_IndexBuffer::~C_IndexBuffer ()
		{
			//	EMPTY
		}

	}	//	namespace RENDER
}	//	namespace REDEEMER

