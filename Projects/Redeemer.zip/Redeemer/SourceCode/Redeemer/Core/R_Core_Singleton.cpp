/*!
**	Redeemer Engine 2010 (C) Copyright by Dominik "squ@ll" Jasi�ski.
**
**	R_Core_Singleton.cpp
**		Implementation of singleton design pattern
*/

//------------------------------------------------------------------------------------------------------------------------
#include "R_Core_Singleton.h"

namespace REDEEMER
{
	namespace CORE
	{
		//------------------------------------------------------------------------------------------------------------------------

	}	//	namespace CORE
}	//	namespace REDEEMER
